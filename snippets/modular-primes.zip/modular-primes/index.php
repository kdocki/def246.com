<h2>Two smallest prime numbers <small>(that have remainders 1 less than their divisor)</small></h2>
<?php
  print "<pre>";
  #require_once("main.php");
  # to keep the load down on the server I just copied the answer 
  # into a static file so we don't keep computing the answer
  print file_get_contents("answer.txt");
  print "</pre>";
?>

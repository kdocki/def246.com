<?php

require_once("isPrime.php");

function main()
{
  $max = 10; 	# check mod 2 - 10
  $i = 5000;	# start iterator at 5000 (I already know the answer)
  $count = 2;	# how many primes should we find?

  while ($count != 0)
  {

    # find a possible answer
    $answer = $i;
    for($n=2; $n<=$max; $n++)
    {
      if ($i % $n != ($n-1)) { $answer = 0; break; }
    }

    # check to see if this is an answer and also primality
    if($answer == $i && isPrime($answer))
    {
      print "Answer: $answer\n";
      for($n=2; $n<=$max; $n++)
      {
        $mod = $answer % $n;
        $divisor=($answer - $mod)/$n;

        print " -> $n ($divisor) + $mod = " . $answer ;
        print "\n";
      }
      print "\n";
      $count--;
    }
    $i++;
  }
}



main();



?>

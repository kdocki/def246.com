<?php

function isPrime($Num)
{
  $No = 0;
  for($CurrNum = 2; $CurrNum <= $Num; $CurrNum++)
  {
    for($Divisor = 2; $Divisor < $CurrNum; $Divisor++)
    {
      $Res = $CurrNum / $Divisor;
      if($Res != 1 && intval($Res) == $Res)
      {
        $No = 1;
        $Divisor = $CurrNum;
      }
    }
    if($No != 1) { $Result = $CurrNum; }
    $No = 0;
 }
  if($Result == $Num) { return 1; }
  else { return 0; }
}

?>

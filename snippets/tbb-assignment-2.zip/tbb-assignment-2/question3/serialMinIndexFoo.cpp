/* File:  
 *    serialMinIndexFoo.cpp
 *
 * Purpose:
 *    Let's check out the serial run time to find min foo
 *
 * Compile:
 *    make serialMinIndexFoo
 *
 * Usage:
 *	  ./serialMinIndexFoo [-debug] <problem size>
 *
 * Output:
 *	  time taken to run program
 *    if debug mode is enabled then we output a test case
 */

#include "MinIndexFoo.h"

/*
 * main(arguments)
 * get arguments for program and returns time taken to solve()
 */
int main(int argc, char *argv[])
{
	bool debug = false;
	size_t problem_size = 0;
    int argi = 1;

	// get arguments for this program
    if (argc < 2 || argc > 3) {
        fprintf(stderr, "usage: ./serialMinIndexFoo [-debug] <problem size>\n");
        return -1;
    }

	// enable debug mode which prints out test case
    if (argi < argc) {
		if (strcmp("-debug", argv[argi]) == 0) {
			debug = true;
			argi++;
		}
	}

	// get the problem size
    problem_size = strtol(argv[argi++],0,0);

	// create
	MinIndexFoo foo = MinIndexFoo(problem_size);

	// if we are testing then we need to use the same Foo 
	// for parallel and sequential programs
	if(debug) foo.CreateTestCase();
	
	// Get the start time
    tbb::tick_count t0 = tbb::tick_count::now();

	// Solve sequentially
	foo.SerialMinIndexFoo();
	
	// Get the end time
    tbb::tick_count t1 = tbb::tick_count::now();

	// print out the answer (should be the same as above print)
    if (debug) foo.print();

	// output time for our csv file
    std::cout << (t1-t0).seconds();
}


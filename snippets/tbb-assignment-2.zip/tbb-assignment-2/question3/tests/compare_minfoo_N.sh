#!/bin/bash

echo "Starting batch test run"
date

par=parMinIndexFoo
seq=serialMinIndexFoo
csv=tests/compare.csv
thread=8
grain=10000

[ -f "$csv" ] && rm $csv

# size of problem
for p in 10 100 1000 100000 1000000 10000000 100000000 500000000 1000000000; do
	echo -ne "$p," >> $csv
	./$seq $p >> $csv
	echo -ne "," >> $csv
	./$par $p $grain $thread >> $csv

	echo "" >> $csv
done

echo "Finished batch test run"
date

#!/bin/bash

echo "Starting batch test run"
date

par=parMinIndexFoo
seq=serialMinIndexFoo

# try for problem size m = 100000000
for m in 100000000; do
	[ -f "tests/$seq.$m.csv" ] && rm tests/$seq.$m.csv
	[ -f "tests/$par.$m.csv" ] && rm tests/$par.$m.csv

	# get the average run time over 5 instances
	echo -ne "1" > tests/$seq.$m.csv
	for e in 1 2 3 4 5; do
		 echo -ne "," >> tests/$seq.$m.csv
		./$seq $m >> tests/$seq.$m.csv
	done

	for thread in {1..8}; do
	  for grain in 2 4 8 16 32 64 128 256 512 1024 2048 4096 8192; do

	   # start row $m
	   echo -ne "$thread,$grain" >> tests/$par.$m.csv
		
	   # we are going to take the average time out of 5 runs
 	   for e in 1 2 3 4 5; do
		echo -ne "," >> tests/$par.$m.csv

		./$par $m $grain $thread >> tests/$par.$m.csv
	   done

	   # add a new line to the row
	   echo "" >> tests/$par.$m.csv
	  done
	done
done

echo "Finished batch test run"
date

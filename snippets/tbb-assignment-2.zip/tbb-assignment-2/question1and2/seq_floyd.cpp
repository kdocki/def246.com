/* File:  
 *    seq_floyd
 *
 * Purpose:
 *    Let's check out the serial run time for the floyd marshall algorithm
 *
 * Compile:
 *    make seq_floyd
 *
 * Usage:
 *	  ./seq_floyd <matrix size> [-debug]
 *
 * Output:
 *	  time taken to run program
 *    if debug mode is enabled then we output a before and after matrix
 */

#include "FloydMatrixSequential.h"

/*
 * main(arguments)
 * get arguments for program and returns time taken to execute fm.solve()
 */
int main(int argc, char *argv[])
{
	size_t matrix_size;
	bool debug = false;
	bool test = false;
    int argi = 1;

	// get arguments for this program
    if (argc < 2 || argc > 3) {
        fprintf(stderr, "usage: ./seq_floyd <matrix size> [-debug | -test]\n");
        return -1;
    }

	// get the matrix size
    matrix_size = strtol(argv[argi++],0,0);
	
	// enable debug mode which prints out matrix
    if (argi < argc) {
		if (strcmp("-debug", argv[argi]) == 0) {
			debug = true;
			argi++;
		} else if (strcmp("-test", argv[argi]) == 0) {
			test = true;
			argi++;
		}
	}
	
	// create a new random FloydMatrix
	FloydMatrix fm = FloydMatrix(matrix_size);

	// if we are testing then we need to use the same base matrix 
	// for parallel and sequential programs
	if(test) fm.CreateTestMatrix();

	// print the matrix if debug is on
    if (debug || test) fm.print();
	
	// Get the start time
    tbb::tick_count t0 = tbb::tick_count::now();

	// Solve sequentially
	fm.solve(0);

	// Get the end time
    tbb::tick_count t1 = tbb::tick_count::now();
	
	// output time for our csv file
    std::cout << (t1-t0).seconds();

	// print out the matrix now that we changed it
    if (debug || test) fm.print();
}

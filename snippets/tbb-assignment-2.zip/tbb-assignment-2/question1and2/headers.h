#include <cstdlib>
#include <cstdio>
#include <cstring>

#include <utility>
#include <iostream>
#include <iomanip>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <assert.h>

#include "tbb/task_scheduler_init.h"
#include "tbb/blocked_range.h"
#include "tbb/tbb.h"
#include "tbb/tick_count.h"

using namespace tbb;

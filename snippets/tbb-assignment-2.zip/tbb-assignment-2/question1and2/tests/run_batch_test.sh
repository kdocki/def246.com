#!/bin/bash

echo "Starting batch test run"
date

seq=seq_floyd
tbb1=tbb_floyd_1d
tbb2=tbb_floyd_2d

# try for matrix size m = 1000
for m in 1000; do
	[ -f "tests/$seq.$m.csv" ] && rm tests/$seq.$m.csv
	[ -f "tests/$tbb1.$m.csv" ] && rm tests/$tbb1.$m.csv
	[ -f "tests/$tbb2.$m.csv" ] && rm tests/$tbb2.$m.csv

	# get the average run time over 5 instances
	echo -ne "1" > tests/$seq.$m.csv
	for e in 1 2 3 4 5; do
		 echo -ne "," >> tests/$seq.$m.csv
		./$seq $m >> tests/$seq.$m.csv
	done


	touch tests/$tbb1.$m.csv
	touch tests/$tbb2.$m.csv
	
	for thread in {1..8}; do
	  for grain in 2 4 8 16 32 64 128 256 512 1024; do

	   # start row $m
	   echo -ne "$thread,$grain" >> tests/$tbb1.$m.csv
	   echo -ne "$thread,$grain" >> tests/$tbb2.$m.csv
		
		   # we are going to take the average time out of 5 runs
 	   for e in 1 2 3 4 5; do
		echo -ne "," >> tests/$tbb1.$m.csv
		echo -ne "," >> tests/$tbb2.$m.csv

		./$tbb1 $m $grain $thread >> tests/$tbb1.$m.csv
		./$tbb2 $m $grain $thread >> tests/$tbb2.$m.csv
	   done

	   # add a new line to the row
	   echo "" >> tests/$tbb1.$m.csv
	   echo "" >> tests/$tbb2.$m.csv
	  done
	done
done

echo "Finished batch test run"
date

/* File:  
 *    tbb_floyd
 *
 * Purpose:
 *    Use TBB to paralellize the floyd marshall algorithm
 *
 * Compile:
 *    make ttb_floyd
 *
 * Usage:
 *	  ./ttb_floyd_2d <matrix size> <grain size (use 0 for auto)> [-debug | -test] [thread count = -1]
 *
 * Output:
 *	  time taken to run program
 *    if debug mode is enabled then we output a before and after matrix
 */

#include "FloydMatrixParallel2d.h"

int main(int argc, char *argv[])
{
	size_t matrix_size;
	size_t grain_size;

    int argi = 1;	
	int num_threads = -1;
	bool debug = false;
	bool test = false;
	bool simple = true;
	
	// get arguments for this program
    if (argc < 3 || argc > 5) {
        fprintf(stderr, "usage: ./ttb_floyd_2d <matrix size> <grain size (use 0 for auto)> [-debug | -test | -auto] [thread count = -1]\n");
        return -1;
    }

	// get the matrix size
    matrix_size = strtol(argv[argi++],0,0);
	
	// get the grain size
	grain_size = strtol(argv[argi++], 0,0);

	// enable debug mode which prints out matrix
    if (argi < argc) {
		if (strcmp("-debug", argv[argi]) == 0) {
			debug = true;
			argi++;
		} else if (strcmp("-test", argv[argi]) == 0) {
			test = true;
			argi++;
		} else if (strcmp("-auto", argv[argi]) == 0) {
			simple = false;
			argi++;
		}
	}
	
	// get the number of threads
    if (argi < argc) {
        num_threads = atol(argv[argi]);
        if (num_threads <= 0 || num_threads > 64) {
            fprintf(stderr, "error specifying number of threads\n");
            return -1;
        }
    }
	
	// create a new random FloydMatrix
	FloydMatrix fm = FloydMatrix(matrix_size);

	// if we are testing then we need to use the same base matrix 
	// for parallel and sequential programs
	if(test) fm.CreateTestMatrix();
	
	// print the matrix if debug is on
    if (debug || test) fm.print();
	
    // Start up scheduler
    task_scheduler_init init(num_threads);

	// Get the start time
    tbb::tick_count t0 = tbb::tick_count::now();

	// Do parallelization here
	fm.solve(grain_size, simple);

	// Get the end time
    tbb::tick_count t1 = tbb::tick_count::now();
	
	// output time for our csv file
    std::cout << (t1-t0).seconds();

	// print out the matrix now that we changed it
    if (debug || test) fm.print();
}

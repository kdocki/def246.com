<?php

  require_once("jedi-aux.php");

  function sortList($keys, $list)
  {
    # get a list of people that are better than me then print my name
    foreach ($keys as $name) { whoIsBetter($name, $list); printJedi($name); }
    
    # get a list of people worse than me 
    foreach ($keys as $name) { whoIsWorse($name, $list); }
  }

  function main()
  {
    $list = getJediList("jedi.txt");
    $jedi = array_keys($list);
    sortList($jedi, $list);
  }

  main();

?>

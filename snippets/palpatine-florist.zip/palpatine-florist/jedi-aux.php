<?php

  # this function returns an array of Jedi names
  # and each array has a list of Jedi that are weaker
  function getJediList($filename)
  {
    $handle = fopen($filename, 'r');
    $list = array();

    while (!feof($handle))
    {
      $buffer = fgets($handle);
      $words = explode(" ", $buffer);

      $words[0] = trim($words[0]);
      $words[1] = trim($words[1]);

      if(!empty($words[0])){ $list[$words[0]][] = $words[1]; }
    }

    fclose($handle);
    return $list;
  }

  $p = array(); # global variable to keep up with Jedi names we have printed
  function printJedi($name)
  {
    if($GLOBALS['p'][$name] != 1) print "$name\n";
    $GLOBALS['p'][$name] = 1;
  }

  function whoIsBetter($name, $list)
  {
    foreach ($list as $key => $value)
    {
      if($key != $name)
      {
         foreach ($value as $item) { if($item == $name) printJedi("$key"); }
      }
    }
  }

  function whoIsWorse($name, $list)
  {
    foreach ($list[$name] as $value){ printJedi($value); }
  }

?>

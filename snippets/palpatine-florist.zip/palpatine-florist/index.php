<h2>Jedi List <small>(sorted most powerful to least powerful)</small></h2>
<?php
  print "<pre>";
  require_once("jedi.php");
  print "</pre>";
?>
<h2>Sorted from this Jedi list</h2>
<?php print "<pre>" . file_get_contents("jedi.txt") . "</pre>"; ?>

<?php

  require_once("Fn.php");
  
  $n = $argv[1];
  $x = $argv[2];
  print "Fn($n,$x) = " . Fn($n,$x);
  print "\n";
?>

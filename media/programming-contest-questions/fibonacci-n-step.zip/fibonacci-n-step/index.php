<?php 

  $MAX_STEPS = 10;
  $MAX_X = 30;

  require_once("Fn.php");
  SeiveFn($MAX_STEPS, $MAX_X);
?>

<html>
<head>
  <style>@import url(style.css);</style>
  <style>
    <?php
        for($i = 2; $i <= $MAX_STEPS; $i++) 
        {
          $power = pow(2, $i) - 1;
          $mod = $i % 2;
          
          if ($mod) print ".r$power { background-color: lightCoral; }";
          else print ".r$power { background-color: lightSalmon; }";
        }
    ?>
  </style>
</head>
<body>
<table>
  <thead>
  <tr>
    <th>x</th>
    <?php for($step = 2; $step <= $MAX_STEPS; $step++) print "<th>Fn($step, x)</th>\n"; ?>
  </tr>
  </thead>
  <tbody>
  <?php
    for($x = 1; $x <= $MAX_X; $x++)
    {
      print "<tr>\n";
      for($n = 1; $n <= $MAX_STEPS; $n++)
      { 
        $result = Fn($n, $x);
        $style = $n % 2;
        if($n == 1) print "<td>$x</td>\n";
        else print "<td class=\"s$style r$result\">$result</td>\n";
      }
      print "</tr>\n";
    }
  ?>
  </tbody>
</table>
</body>
</html>

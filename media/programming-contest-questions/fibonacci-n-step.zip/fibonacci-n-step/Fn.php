<?php
  
  $F1 = array(0 => 0, 1 => 1, 2 => 1);
  $Fn = array(1 => $F1);

  function Fn($step, $x)
  {
    global $Fn;
    if (!isset($Fn[$step][$x])) SeiveFn($step, $x);
    return $Fn[$step][$x];
  }

  function SeiveFn($step, $x)
  {
    global $Fn;

    if(!isset($Fn[$step]))
    {
      if(!isset($Fn[$step - 1])) SeiveFn($step - 1, $x);
      $Fn[$step] = $Fn[$step - 1];
    }

    for($i = $step + 1; $i <= $x; $i++)
    { 
      $sum = 0;
      for($n = $i - 1; $n >= $i - $step; $n--) $sum = $sum + $Fn[$step][$n];
      $Fn[$step][$i] = $sum;
    }
  }

?>


sprite.prototype._id;
sprite.prototype.getId = function() { return this._id; }

function sprite(id) {
  this._id = id;
}


var maxX = 500; // they all
var maxY = 250; // get re-adjusted
var myPosX = 0; // this one too
var myPosY = 0; // same here
var width = 320;    // width of individual sprite image
var height = 240;   // height of individual sprite image

var picsPerRow = 4; // number of pictures per row
var numOfRows = 4;  // this is the number of rows you have
var numOfPics = picsPerRow * numOfRows;
var top_left;
var top_right;
var bottom_left;
var bottom_right;

function changePic(obj, ev)
{
    if (posY() > maxY && posX() > maxX) 
	obj.style.backgroundImage = "url("+bottom_right+")";
    if (posY() > maxY && posX() < maxX) 
	obj.style.backgroundImage = "url("+bottom_left+")";
    if (posY() < maxY && posX() > maxX)
	obj.style.backgroundImage = "url("+top_right+")";
    if (posY() < maxY && posX() < maxX)
	obj.style.backgroundImage = "url("+top_left+")";
}

function findPos(obj)
{
  var curleft = curtop = 0;
  if (obj.offsetParent) {
  do {
        curleft += obj.offsetLeft;
        curtop += obj.offsetTop;
     } while (obj = obj.offsetParent);
 
  }
  return [curleft,curtop];
}


function getPicNum(obj, ev)
{
  // returns the position of picture's top leftmost corner
  var divLoc = findPos(obj);
  
  // since this is a circle, find the delta X and delta Y
  var dX = Math.abs(posX() - (divLoc[0] + obj.offsetWidth/2));
  var dY = Math.abs(posY() - (divLoc[1] + obj.offsetHeight/2));

  // find the angle of mouse pointer relavant to our picture
  var degrees = Math.floor(Math.atan(dY/dX) * 180/Math.PI);
  
  // puts the center of Circle at the center of the picture
  maxX = divLoc[0] + width/2;
  maxY = divLoc[1] + height/2

  // below we find what picture in the sprite should be used
  // by doing a ratio of n/16 = deg/45
  // if the deg is greater than 45 we need to make the 
  // ratio start decreasing so we don't have an
  // entire skip in our animations
  if (degrees > 45) degrees = 90 - degrees;
  return Math.floor((numOfPics-1) * degrees/45);
}

function animateSprite(event)
{
  var obj, style;
  var loc, xLoc, yLoc;

  setPosX(event);
  setPosY(event);

  if (isLoaded())
  {
    if(document.getElementById && (obj = document.getElementById(id)) && (style = obj.style))
    {
      changePic(obj);
    
      var loc = getPicNum(obj);
      var xLoc = (loc % picsPerRow) * obj.offsetWidth;
      var yLoc = Math.floor(loc/picsPerRow) * obj.offsetHeight;
      style.backgroundPosition = '-'+xLoc+'px -'+yLoc+'px';
    }
  }
}

var numPicsLoaded = new Array();
function finished(x){ numPicsLoaded[x] = 1; }
function isLoaded() { return (numPicsLoaded.length >= 4); }
function loadPictures(top_left, top_right, bottom_left, bottom_right)
{
  var image0 = new Image();
  var image1 = new Image();
  var image2 = new Image();
  var image3 = new Image();

  image0.onload = function () { finished(0); }
  image1.onload = function () { finished(1); }
  image2.onload = function () { finished(2); }
  image3.onload = function () { finished(3); }

  image0.src = top_left; 
  image1.src = top_right; 
  image2.src = bottom_left; 
  image3.src = bottom_right;
}

function startAnimation(objId, spritedb)
{
  top_left = spritedb+"/top_left.jpg";
  top_right = spritedb+"/top_right.jpg";
  bottom_left = spritedb+"/bottom_left.jpg";
  bottom_right = spritedb+"/bottom_right.jpg";

  loadPictures(top_left, top_right, bottom_left, bottom_right); 
  id = objId;
}


document.onmousemove=animateSprite;

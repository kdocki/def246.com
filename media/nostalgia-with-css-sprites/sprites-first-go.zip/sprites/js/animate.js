var myPosX, myPosY;
var s = new Array();

function posX() { return myPosX; }
function posY() { return myPosY; }
function setPosX(ev) { var ev = ev || window.event; myPosX = ev.clientX; }
function setPosY(ev) { var ev = ev || window.event; myPosY = ev.clientY; }


function createSprite(objId, objCenterId, spriteDB, picsPerRow, numOfRows)
{
  var sprite = new MouseMoveSprite(objId, spriteDB, picsPerRow, numOfRows);
  sprite.loadPictures();
  
  if (objCenterId != null) sprite.setCenter(objCenterId);
  s.push(sprite);
}

var allLoaded = false;
function animateSprites(event)
{
  setPosX(event);
  setPosY(event);

  if(allLoaded)
  {
    for ( var i in s ) s[i].animate();
  }
  else
  {
    for ( var i in s )
      if(s[i].isLoaded() == false) return 0;

    allLoaded = true;
  }
}

document.onmousemove=animateSprites;


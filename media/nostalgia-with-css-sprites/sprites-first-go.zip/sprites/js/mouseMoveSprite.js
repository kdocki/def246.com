

/**********************************************************
 * MouseMoveSprite Class                                  *
 * Constructed by Kelt Dockins <contact@keltdockins.com>  *
 *                                                        *
 * Allows you to easily animate Sprites based on mouse    *
 * movements.                                             *
 *********************************************************/

MouseMoveSprite.prototype.constructor = MouseMoveSprite();
MouseMoveSprite.prototype.animate = function ()
{
  var a = this;
  var obj, style;
  if (a.isLoaded())
  {
    if(document.getElementById && (obj = document.getElementById(a._id)) && (style = obj.style))
    {
      a.changePic();
    
      var loc = a.getPicNum();
      var xLoc = (loc % a._picsPerRow) * obj.offsetWidth;
      var yLoc = Math.floor(loc/a._picsPerRow) * obj.offsetHeight;
 
      style.backgroundPosition = '-'+xLoc+'px -'+yLoc+'px';
    }
  }
};


MouseMoveSprite.prototype.findPosition = function()
{
  var a = this;
  var obj, style;
  var curleft = curtop = 0;
  if(document.getElementById && (obj = document.getElementById(a._centerObjId)) && (style = obj.style))
  {
    if (obj.offsetParent)
    {
      do {
        curleft += obj.offsetLeft;
        curtop += obj.offsetTop;
      } while (obj = obj.offsetParent);
    }
  }
  return [curleft,curtop];
};


MouseMoveSprite.prototype.getPicNum = function()
{
    var a = this;
    var obj, style;
    if(document.getElementById && (obj = document.getElementById(a._centerObjId)) && (style = obj.style))
    {
      // returns the position of picture's top leftmost corner
      var divLoc = a.findPosition();

      // since this is a circle, find the delta X and delta Y
      var dX = Math.abs(posX() - (divLoc[0] + obj.offsetWidth / 2));
      var dY = Math.abs(posY() - (divLoc[1] + obj.offsetHeight / 2));

      // find the angle of mouse pointer relavant to our picture
      var degrees = Math.floor(Math.atan(dY/dX) * 180/Math.PI);

      // puts the center of Circle at the center of the picture
      a._maxX = divLoc[0] + obj.offsetWidth/2;
      a._maxY = divLoc[1] + obj.offsetWidth/2;

      // below we find what picture in the sprite should be used
      // by doing a ratio of n/16 = deg/45
      // if the deg is greater than 45 we need to make the 
      // ratio start decreasing so we don't have an
      // entire skip in our animations
      if (degrees > 45) degrees = 90 - degrees;
      return Math.floor((a._numOfPics - 1) * degrees/45);
    } else return 0;  // this shouldn't happen, but just to be safe...
};


MouseMoveSprite.prototype.finished = function(){ this._numLoaded++; };
MouseMoveSprite.prototype.isLoaded = function() { return (this._numLoaded >= 4); };

MouseMoveSprite.prototype.changePic = function()
{
  var a = this;
  var obj, style;
  if(document.getElementById && (obj = document.getElementById(a._id)) && (style = obj.style))
  {
    if (posY() > a._maxY && posX() > a._maxX) style.backgroundImage = "url("+a._bottom_right+")";
    if (posY() > a._maxY && posX() < a._maxX) style.backgroundImage = "url("+a._bottom_left+")";
    if (posY() < a._maxY && posX() > a._maxX) style.backgroundImage = "url("+a._top_right+")";
    if (posY() < a._maxY && posX() < a._maxX) style.backgroundImage = "url("+a._top_left+")";
  }
};


MouseMoveSprite.prototype.loadPictures = function()
{ 
  var a = this;

  var image0 = new Image(); 
  var image1 = new Image(); 
  var image2 = new Image();
  var image3 = new Image();
  
  image0.onload = function () { a.finished(); };
  image1.onload = function () { a.finished(); };
  image2.onload = function () { a.finished(); };
  image3.onload = function () { a.finished(); };

  image0.src = a._top_left; 
  image1.src = a._top_right; 
  image2.src = a._bottom_left; 
  image3.src = a._bottom_right;
};

MouseMoveSprite.prototype.setCenter = function(centerObjId){ this._centerObjId = centerObjId; }

MouseMoveSprite.prototype._numLoaded = 0;
MouseMoveSprite.prototype._maxX = 500;
MouseMoveSprite.prototype._maxY = 60;

function MouseMoveSprite(id, spriteDB, picsPerRow, numOfRows)
{
  if (spriteDB == null) spriteDB = "sprites";
  if (picsPerRow == null) picsPerRow = 4;
  if (numOfRows == null) numOfRows = 4;

  this._id = id;
  this._centerObjId = id;
  this._picsPerRow = picsPerRow;
  this._numOfRows = numOfRows;

  this._top_left = spriteDB+"/top_left.jpg";
  this._top_right = spriteDB+"/top_right.jpg";
  this._bottom_left= spriteDB+"/bottom_left.jpg";
  this._bottom_right = spriteDB+"/bottom_right.jpg";

  this._numOfPics = this._picsPerRow * this._numOfRows;
}

